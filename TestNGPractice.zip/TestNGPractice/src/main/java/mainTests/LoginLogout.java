package mainTests;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;
import pageObjects.AddCartPage;
import pageObjects.LoginPage;
import pageObjects.YourCartPage;
import utilities.AbstractUtility;

public class LoginLogout{

	WebDriver driver;
	
	public LoginPage lp;
	public YourCartPage cartAction;
	 
	public AddCartPage addCart;
	
	@BeforeTest
	@Parameters({"url"})
	public void Launch(String url)
	{
		ChromeOptions chromeOptions = new ChromeOptions();
		chromeOptions.addArguments("--disable-search-engine-choice-screen");
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver(chromeOptions);
		//System.setProperty("webdriver.chrome.driver",System.getProperty("User.dir")+"//Driver/chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","C:/Users/tasmi/eclipse-workspace/TestNGFramework/Drivers/chromedriver.exe");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get(url);
		driver.manage().window().maximize();
	}
	
	
	
	@Test(priority=1)
	@Parameters({"user","pass"})
	public void LoginUser(String user,String pass) throws InterruptedException
	{
		
		lp = new LoginPage(driver);
		lp.Login(user, pass);
		System.out.println(driver.getTitle());
		System.out.println("Login Test Success");
	}
	
	@Test(priority=2)
	public void AddCartItems() throws InterruptedException
	{
		System.out.println(driver.getTitle());
		addCart = new AddCartPage(driver);
		addCart.AddCart();
		
		System.out.println("Add cart Test Success");
	}
	
	@Test(priority=3)
	public void RemoveCartContinueShoppingAction() throws InterruptedException 
	{
		System.out.println(driver.getTitle());
		cartAction = new YourCartPage(driver);
		
		cartAction.RemoveCart();
		cartAction.ContinueCart();
	}
	
	
	@AfterTest
	public void CloseApp()
	{
		driver.close();	
		}
	
}
