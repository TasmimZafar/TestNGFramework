package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import utilities.AbstractUtility;

public class YourCartPage extends AbstractUtility{

	WebDriver driver;
	
	public YourCartPage (WebDriver driver) 
	{   super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="//button[contains(text(),'Remove')]")
	WebElement RemoveCart;
	
	@FindBy(name = "continue-shopping")
	WebElement ContinueShopping;
	
	
	public void RemoveCart() throws InterruptedException
	{
		Thread.sleep(1000);
		WaitForElementToAppear(RemoveCart);
		RemoveCart.click();
		Thread.sleep(2000);
		//WaitForElementToAppear(addJacket);
		Thread.sleep(1000);
		WaitForElementToAppear(ContinueShopping);
		System.out.println("Remove cart Test Success");
		//Thread.sleep(5000);
		
	}
	
	public void ContinueCart() throws InterruptedException
	{
		Thread.sleep(1000);
		WaitForElementToAppear(ContinueShopping);
		ContinueShopping.click();
		System.out.println("Continue cart Test Success");
	}
	
	
}
	