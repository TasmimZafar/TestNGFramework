package pageObjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import utilities.AbstractUtility;

public class LoginPage extends AbstractUtility{

	WebDriver driver;
	
	public LoginPage (WebDriver driver) 
	{
		super(driver);
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(name="user-name")
	WebElement username;
	
	@FindBy(id="password")
	WebElement password;
	
	@FindBy(id="login-button")
	WebElement submitbtn;
	
	
	public void Login(String user,String pass) throws InterruptedException
	{
		WaitForElementToAppear(username);
		username.click();
		username.sendKeys(user);
		password.sendKeys(pass);
		WaitForElementToAppear(submitbtn);
		Thread.sleep(1000);
		submitbtn.click();
		
		Thread.sleep(1000);
		//driver.switchTo().alert().accept();
	}
}
	